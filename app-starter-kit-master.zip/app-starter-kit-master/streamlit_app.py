import streamlit as st

st.title('🎈 App Name')

st.write('Hello world!')
